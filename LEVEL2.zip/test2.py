import random
class Board():
    def __init__(self):
        self.position = [[" " for j in range(3)] for i in range(3)]
 
    def print_board(self):
        print('  --- ' + '--- ' + '---')
        print(' | ' + self.position[0][0] + ' | ' + self.position[0][1] + ' | ' + self.position[0][2] + ' | ')
        print('  --- ' + '--- ' + '---')
        print(' | ' + self.position[1][0] + ' | ' + self.position[1][1] + ' | ' + self.position[1][2] + ' | ')
        print('  --- ' + '--- ' + '---')
        print(' | ' + self.position[2][0] + ' | ' + self.position[2][1] + ' | ' + self.position[2][2] + ' | ')
        print('  --- ' + '--- ' + '---')
 
    def update_position(self, row, column, player):
        if self.position[row][column] == " ":
            self.position[row][column] = player
 
    def winner(self,player):
               
        if self.position[0][0]==player and self.position[0][1]==player and self.position[0][2]==player:  #top row
            return True
            
        if self.position[1][0]==player and self.position[1][1]==player and self.position[1][2]==player: #middle row
            return True    
        
        if self.position[2][0]==player and self.position[2][1]==player and self.position[2][2]==player: #bottom row
            return True
        
        if self.position[0][0]==player and self.position[1][0]==player and self.position[2][0]==player: #first column
            return True         
        
        if self.position[0][1]==player and self.position[1][1]==player and self.position[2][1]==player: #middle column
            return True
 
        if self.position[0][2]==player and self.position[1][2]==player and self.position[2][2]==player: #last column
            return True
 
        if self.position[0][0]==player and self.position[1][1]==player and self.position[2][2]==player: #diagonal
            return True
 
        if self.position[0][2]==player and self.position[1][1]==player and self.position[2][0]==player: #diagonal
            return True
    
    def tie(self):
        occupied = 0
        for d in self.position:
            for i in d:
                if i == "X" or i == "O":
                    occupied += 1
        
        if occupied == 9:
            return True
        else:
            return False   

    def comp_move(self, player):
        r = random.randint(0,2)
        c = random.randint(0,2)
        if self.position[r][c] == " ":
            self.update_position(r, c, player)
            self.print_board()
            if self.winner(player):
                print("Computer wins!")
        else:
            self.comp_move("O")     
  
board = Board() 
board.print_board()  
while True:
    x_row , x_column = input("It is player 1's turn: \nEnter Move: ").split()
    board.update_position(int(x_row), int(x_column), "X")
    board.print_board()
    if board.winner("X"):
        print("\nPlayer 1 wins!!!\n")
        break
    if board.tie():
        print("TIE!")
        break 
    
    board.comp_move("O")
    if board.tie():
        print("TIE!")
        break 
    